abstract class ShopLayoutStates{}
class ShopLayoutInitialStates extends ShopLayoutStates{}
class ShopLayoutChangeBottomNavStates extends ShopLayoutStates{}

class ShopLoadingHomeDataState extends ShopLayoutStates{}
class ShopSuccessHomeDataState extends ShopLayoutStates{}
class ShopErrorHomeDataState extends ShopLayoutStates{}
class ShopSuccessCategoryDataState extends ShopLayoutStates{}
class ShopErrorCategoryDataState extends ShopLayoutStates{}

class ShopSuccessChangeFavoritesState extends ShopLayoutStates{}
class ShopErrorChangeFavoritesState extends ShopLayoutStates{}
class CategoryModel
{
  late bool status;
  late CategoryDataModel data;
  CategoryModel.fromJson(Map<String,dynamic>json)
  {
    status=json['status'];
    data=CategoryDataModel.fromJson(json['data']);
  }
}
class CategoryDataModel
{
  late int currentPage;
  List<CategoryData>myData=[];
  CategoryDataModel.fromJson(Map<String,dynamic> json)
  {
    currentPage=json['current_page'];
    json['data'].forEach((element)
    {
      myData.add(CategoryData.fromJson(element));
    });
  }

}
class CategoryData
{
  late int id;
  late String name;
  late String image;

  CategoryData.fromJson(Map<String,dynamic>json)
  {
     id=json['id'];
    name=json['name'];
    image=json['image'];
  }
}
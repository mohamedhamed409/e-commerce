import 'package:conditional_builder_null_safety/conditional_builder_null_safety.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shop_app/modules/login/cubit/cubit.dart';
import 'package:shop_app/modules/webview_screen.dart';
import 'package:shop_app/shared/styles/colors.dart';


Widget defaultTextFormField({
  required TextEditingController controller,
  required TextInputType type,
  // required Function onSubmit(val),
  // required Function onChane,
  GestureTapCallback ?onTap,
  required String label,
  required IconData prefix,
  IconData ?suffix,
  bool isPassword=false,
  required FormFieldValidator validate,
  bool isClickable=true,
  ValueChanged? onChange,
  ValueChanged<String>?onSubmit,

//  Function?onChange,
}
    )=>  TextFormField(

  onFieldSubmitted: onSubmit,
  onChanged:onChange ,
  onTap: onTap,
  enabled: isClickable,
  validator: validate,
  controller: controller,
  obscureText:isPassword,
  keyboardType:type ,
  // onFieldSubmitted:(val){onSubmit(val);},
  decoration: InputDecoration(
    labelText: label,
    prefixIcon: Icon(prefix,),
      suffixIcon: suffix!=null?IconButton(icon: Icon(suffix),onPressed:(){}):null,
    border: OutlineInputBorder(),
  ),
  //  border: InputBorder.none,

);

void navigateTo(context,widget)=>Navigator.push(context, MaterialPageRoute(builder: (context)=>widget,));

Widget buildArticleItem(article,context)=>InkWell(
  onTap: ()
  {
    navigateTo(context, WebViewScreen(article['url']));
  },
  child:   Padding  (
    padding: const EdgeInsets.all(20.0),
    child: Row(children: [
      Container(
        width: 120,
        height: 120,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          image: DecorationImage(image: NetworkImage(
              '${article['urlToImage']}'),
            fit: BoxFit.cover,
          ),
        ),
      ),
      const SizedBox(width: 20.0,),
      Expanded(
        child: Container(height: 120.0,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
  
              Expanded(
                child:  Text(
                  '${article['title']}'
                  ,
                  style: Theme.of(context).textTheme.bodyText1,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text('${article['publishedAt']}',style: TextStyle(),),
            ],),
        ),
      ),
  
    ],
    ),
  ),
);

Widget articleBuilder(list,context,{isSearch=false})=>  ConditionalBuilder(condition: (list.length>0),
  builder: (context)=>ListView.separated(
    physics:const BouncingScrollPhysics(),
    itemBuilder: (context,index)=>buildArticleItem(list[index],context),
    separatorBuilder: (context,index)=>Padding(
      padding: const EdgeInsetsDirectional.only(start: 20.0,),
      child: Container(width: double.infinity,height: 2.0,color: Colors.white60,),
    ),
    itemCount: 10,),
  fallback: (context)=>isSearch?Container():Center(child: CircularProgressIndicator()),);

void navigateAndFinish(context,widget)=>
    Navigator.pushAndRemoveUntil(context,
        MaterialPageRoute(builder: (context)=>widget),
            (route) => false);

Widget defaultButton({
  required VoidCallback function,
  required String text,
  Color? myColor,
  bool isNotUpperCase=false,
}
)=>MaterialButton(

  onPressed: function,
  color:myColor ,
  height: 50,
  minWidth:double.infinity,
  child:isNotUpperCase?Text(text):Text(text.toUpperCase()),

);

Widget defaultTextButton
    ({required VoidCallback function,
      required String text,})
=>TextButton(onPressed: function, child: Text(text.toUpperCase()),);
void showToast({required String text,required ToastStates state})=>
Fluttertoast.showToast(
msg: text,
toastLength: Toast.LENGTH_LONG,
gravity: ToastGravity.BOTTOM,
timeInSecForIosWeb: 5,
backgroundColor: chooseToastColor(state),
textColor: Colors.white,
fontSize: 16.0);
enum ToastStates
{
  success,
  warning,
  error,
}
Color chooseToastColor(ToastStates state) {
  Color color;
  switch (state) {
    case ToastStates.success:
      color=Colors.green;
      break;
    case ToastStates.warning:
      color=Colors.amber;
      break;
    case ToastStates.error:
      color=Colors.red;
      break;
  }
  return color;

}
const LOGIN='login';
const HOME='home';
const CATEGORIES='categories';
const FAVORITES='favorites';
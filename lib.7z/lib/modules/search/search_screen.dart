import 'package:flutter/material.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    appBar:AppBar(),//if you do not write this line we can not find the arrow of navigation we made in component
       body: Center(child: Text('Search Screen',style: Theme.of(context).textTheme.bodyMedium,)),
    );
  }
}
